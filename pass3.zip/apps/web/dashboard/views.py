# apps/web/dashboard/views.py
"""
Dashboard views — one shell per role, all sharing the same base template.

Each view performs real DB aggregations for its KPI cards.
Aggregation queries are kept deliberately light (COUNT only) — heavy
analytics belong in dedicated report views (later passes).
"""
import logging

from django.db.models import Count, Q, Sum
from django.shortcuts import redirect, render
from django.views import View

from apps.web.mixins import (
    CollegeAdminRequiredMixin,
    LoginRequiredMixin,
    StudentRequiredMixin,
    TeacherRequiredMixin,
    TenantRequiredMixin,
)

logger = logging.getLogger(__name__)


# ── Generic shell ────────────────────────────────────────────────────────────

class DashboardView(LoginRequiredMixin, TenantRequiredMixin, View):
    """
    Generic dashboard — used as fallback if role-specific redirect fails.
    Also the landing for users with no specific role yet assigned.
    """
    login_url    = "web:login"
    template_name = "web/dashboard/dashboard.html"

    def get(self, request):
        college = request.college
        return render(request, self.template_name, {
            "page_title":    "Dashboard",
            "page_subtitle": college.name,
        })


# ── College Admin Dashboard ──────────────────────────────────────────────────

class AdminDashboardView(CollegeAdminRequiredMixin, View):
    template_name = "web/dashboard/admin_dashboard.html"

    def get(self, request):
        college = request.college

        # Students
        from apps.accounts.models import StudentProfile
        students_qs = StudentProfile.objects.filter(college=college)
        total_students  = students_qs.count()
        active_students = students_qs.filter(status="active").count()

        # Teachers
        from apps.accounts.models import TeacherProfile
        total_teachers = TeacherProfile.objects.filter(college=college).count()

        # Programs / Courses
        from apps.academics.models import Program, Batch
        total_programs = Program.objects.filter(college=college, status="active").count()
        total_batches  = Batch.objects.filter(college=college, status="active").count()

        # Finance — fee invoices
        from apps.finance.models import FeeInvoiceStatus
        try:
            from apps.finance.models import FeeInvoice
            total_fee_collected = (
                FeeInvoice.objects
                .filter(college=college, status=FeeInvoiceStatus.PAID)
                .aggregate(t=Sum("amount_paid"))["t"] or 0
            )
            pending_fees = FeeInvoice.objects.filter(
                college=college,
                status__in=[FeeInvoiceStatus.ISSUED, FeeInvoiceStatus.OVERDUE],
            ).count()
        except Exception:
            total_fee_collected = 0
            pending_fees        = 0

        # Recent students for quick list
        recent_students = (
            students_qs.select_related("user")
            .order_by("-created_at")[:8]
        )

        return render(request, self.template_name, {
            "page_title":     "Dashboard",
            "page_subtitle":  f"{college.name} · Admin Overview",
            # KPIs
            "total_students":       total_students,
            "active_students":      active_students,
            "total_teachers":       total_teachers,
            "total_programs":       total_programs,
            "total_batches":        total_batches,
            "total_fee_collected":  total_fee_collected,
            "pending_fees":         pending_fees,
            # Lists
            "recent_students":      recent_students,
        })


# ── Teacher Dashboard ────────────────────────────────────────────────────────

class TeacherDashboardView(TeacherRequiredMixin, View):
    template_name = "web/dashboard/teacher_dashboard.html"

    def get(self, request):
        college = request.college

        try:
            teacher = request.user.teacher_profile
        except Exception:
            teacher = None

        # Subjects this teacher is teaching this term
        from apps.academics.models import SubjectOffering, Term
        current_term = Term.objects.filter(college=college, is_current=True).first()

        my_offerings = []
        if teacher and current_term:
            my_offerings = (
                SubjectOffering.objects
                .filter(college=college, teacher=teacher, term=current_term, status="active")
                .select_related("subject", "section__batch__program")
                [:10]
            )

        # Student count across my sections
        from apps.academics.models import Enrollment
        my_student_count = 0
        if my_offerings:
            section_ids = list(my_offerings.values_list("section_id", flat=True))
            my_student_count = (
                Enrollment.objects
                .filter(college=college, section__in=section_ids, status="enrolled")
                .values("student")
                .distinct()
                .count()
            )

        return render(request, self.template_name, {
            "page_title":      "Teacher Dashboard",
            "page_subtitle":   f"{college.name} · My Classes",
            "teacher":         teacher,
            "current_term":    current_term,
            "my_offerings":    my_offerings,
            "my_student_count": my_student_count,
        })


# ── Student Dashboard ────────────────────────────────────────────────────────

class StudentDashboardView(StudentRequiredMixin, View):
    template_name = "web/dashboard/student_dashboard.html"

    def get(self, request):
        college = request.college

        try:
            student = request.user.student_profile
        except Exception:
            student = None

        # Current enrollment
        from apps.academics.models import Enrollment, Term
        current_term    = Term.objects.filter(college=college, is_current=True).first()
        current_enroll  = None
        my_subjects     = []

        if student:
            from apps.academics.models import SubjectOffering
            current_enroll = (
                Enrollment.objects
                .filter(college=college, student=student, status="enrolled")
                .select_related("section__batch__program", "academic_year")
                .first()
            )
            if current_enroll and current_term:
                my_subjects = (
                    SubjectOffering.objects
                    .filter(
                        college=college,
                        section=current_enroll.section,
                        term=current_term,
                        status="active",
                    )
                    .select_related("subject", "teacher__user")
                    [:8]
                )

        # Pending fees
        pending_fee_count = 0
        if student:
            try:
                from apps.finance.models import FeeInvoice, FeeInvoiceStatus
                pending_fee_count = FeeInvoice.objects.filter(
                    college=college,
                    student_fee_account__student=student,
                    status__in=[FeeInvoiceStatus.ISSUED, FeeInvoiceStatus.OVERDUE],
                ).count()
            except Exception:
                pass

        return render(request, self.template_name, {
            "page_title":       "My Dashboard",
            "page_subtitle":    f"{college.name}",
            "student":          student,
            "current_term":     current_term,
            "current_enroll":   current_enroll,
            "my_subjects":      my_subjects,
            "pending_fee_count": pending_fee_count,
        })


# ── Root redirect ─────────────────────────────────────────────────────────────

class RootRedirectView(View):
    """GET / — bounce to login or to role-appropriate dashboard."""
    def get(self, request):
        if request.user.is_authenticated:
            from apps.web.utils import get_post_login_redirect
            return redirect(
                get_post_login_redirect(request.user, getattr(request, "college", None))
            )
        return redirect("web:login")


# ── Error pages ───────────────────────────────────────────────────────────────

class NoTenantView(View):
    def get(self, request):
        return render(request, "web/errors/no_tenant.html", status=404)


class SubscriptionRequiredView(View):
    def get(self, request):
        return render(request, "web/errors/subscription_required.html", status=403)


class ForbiddenView(View):
    def get(self, request):
        return render(request, "web/errors/403.html", status=403)

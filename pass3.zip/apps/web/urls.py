# apps/web/urls.py
"""
Top-level URL router for the web layer.
All routes are under app_name = 'web' namespace.

Layout:
  /               Root redirect
  /login/         Login
  /logout/        Logout
  /change-password/
  /register/      Onboarding wizard (3 steps)
  /dashboard/     Generic dashboard shell
  /dashboard/admin/
  /dashboard/teacher/
  /dashboard/student/
  /dashboard/no-tenant/
  /dashboard/subscription-required/
  /college/       College admin management
  /platform/      Platform superuser area
"""
from django.urls import include, path

from apps.web.dashboard.views import RootRedirectView

app_name = "web"

urlpatterns = [
    # Root
    path("", RootRedirectView.as_view(), name="root"),

    # Auth
    path("", include("apps.web.auth.urls")),

    # Dashboards + error pages
    path("dashboard/", include("apps.web.dashboard.urls")),

    # College admin management
    path("college/", include("apps.web.college_admin.urls")),

    # Public onboarding wizard
    path("register/", include("apps.web.onboarding.urls")),

    # Platform superuser
    path("platform/", include("apps.web.platform_admin.urls")),
]
